package com.upload.util;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Service;

import net.sf.jsqlparser.parser.CCJSqlParserUtil;
import net.sf.jsqlparser.statement.Statement;
import net.sf.jsqlparser.statement.select.Select;
@Service
public class QueryValidator {
	
	Logger logger = LogManager.getLogger(QueryValidator.class);
	
	public boolean isSelectQuery(String sqlQuery) {
		try {
	        Statement statement = CCJSqlParserUtil.parse(sqlQuery);
	        return statement instanceof Select;
	    } catch (Exception ex) {
	    	logger.error("Exception while validating sql query : " + GetStackTrace.getMessage(ex));
	        return false;
	    }
	}
}