package com.upload.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class DataBaseUtility {
	Logger logger = LogManager.getLogger(DataBaseUtility.class);

	@Autowired
	Cryptography crypto;

	public Connection getDatabaseConnection(JSONObject databaseconnect) {
		try {
			String connectionPrefix = null;
			String connectionString = null;
			connectionPrefix = ApplicationConstants.POSTGRES_PREFIX;
			connectionString = connectionPrefix.concat(databaseconnect.getString("hostname")).concat("/")
					.concat(databaseconnect.getString("schema"));
//			connectionString = "jdbc:sqlserver://192.168.168.12:1433;databaseName=_Kaleeswaran2022;encrypt=true;trustServerCertificate=true;";
			Class.forName(ApplicationConstants.POSTGRES_DRIVER);
			return DriverManager.getConnection(connectionString,
					databaseconnect.getJSONObject("credentials").getString("userName"),
					crypto.getPlainText(databaseconnect.getJSONObject("credentials").getString("password")));
		} catch (Exception ex) {
			logger.error("Exception while configuring DatabaseConnection : " + GetStackTrace.getMessage(ex));
			return null;
		}
	}

	public boolean executeQuery(Connection connection, String query, String fileName) throws SQLException {
		PreparedStatement statement = null;
		boolean result = false;
		if (new QueryValidator().isSelectQuery(query)) {
			try {
				statement = connection.prepareStatement(query);
				statement.setString(1, fileName);
				ResultSet executeQuery = statement.executeQuery();
				while (executeQuery.next()) {
					result = true;
				}
			} catch (Exception ex) {
				logger.error("Exception while executing query : " + GetStackTrace.getMessage(ex));
			} finally {
				try {
					statement.close();
				} catch (Exception e) {
					logger.error("Exception while configuring DatabaseConnection : " + GetStackTrace.getMessage(e));
				}
			}
		} else {
			logger.info("The query is in violation as only SELECT queries are permitted.");
		}
		return result;
	}
}