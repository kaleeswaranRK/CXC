package com.upload.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.spec.KeySpec;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class FileOperation {
	Logger logger = LogManager.getLogger(FileOperation.class);

	@Autowired
	DataBaseUtility database;

	public List<File> dbcheck(List<File> findFiles, JSONObject databaseConnect, String encryptPath) {
		List<File> encryptFiles = new ArrayList<File>();
		Connection databaseConnection = database.getDatabaseConnection(databaseConnect);
		if (databaseConnection != null) {
			for (int i = 0; i < findFiles.size(); i++) {
				String filename = findFiles.get(i).getName().replace(".wav", "");
				try {
					if (database.executeQuery(databaseConnection, databaseConnect.getString("query"), filename)) {
						File fileEncryption = fileEncryption(findFiles.get(i).toString(),
								Paths.get(encryptPath).resolve(findFiles.get(i).getName()).toString());
						if (fileEncryption != null) {
							encryptFiles.add(fileEncryption);
						}
					}
				} catch (Exception e) {
					logger.error("Exception while check and encrypt : " + e);
				}
			}
			try {
				databaseConnection.close();
			} catch (Exception e) {
				logger.error("Exception while connect database : " + e);
			}
			return encryptFiles;
		} else {
			return null;
		}

	}

	public JSONArray deleteFileMethod(JSONArray upload, String encryptPath, String localPath) {
		for (int i = 0; i < upload.length(); i++) {
			if ("success".contains(upload.getJSONObject(i).getString("uploadStatus"))) {
				upload.getJSONObject(i).put("fileSize", getFileSizeWithSuffix(
						new File(Paths.get(localPath).resolve(upload.getJSONObject(i).getString("fileName")).toString())
								.length()));
				if (fileRemove(encryptPath, upload.getJSONObject(i).getString("fileName"))
						&& fileRemove(localPath, upload.getJSONObject(i).getString("fileName"))) {
					upload.getJSONObject(i).put("removeStatus", "success");

				} else {
					upload.getJSONObject(i).put("removeStatus", "failiure");
				}
			} else {
				upload.getJSONObject(i).put("removeStaus", "failiure");
			}
		}
		return upload;
	}

	private boolean fileRemove(String path, String fileName) {
		try {
			File file = new File(Paths.get(path).resolve(fileName).toString());
			return file.delete();
		} catch (Exception e) {
			logger.error("Error while Remove file : " + GetStackTrace.getMessage(e));
			return false;
		}

	}

	public void removeAllFiles(String path) {
		Path folder = Paths.get(path);
		try {
			Files.walk(folder).filter(file -> file.toFile().isFile()).forEach(file -> file.toFile().delete());
		} catch (Exception e) {
			logger.error("Error while Remove file : " + GetStackTrace.getMessage(e));
		}
	}

	private String getFileSizeWithSuffix(long fileSize) {
		double size = fileSize;
		String suffix = "B";
		if (size > 1024) {
			suffix = "KB";
			size /= 1024;
		}
		if (size > 1024) {
			suffix = "MB";
			size /= 1024;
		}
		if (size > 1024) {
			suffix = "GB";
			size /= 1024;
		}
		return String.format("%.2f %s", size, suffix);
	}

	public List<File> findFiles(String location, String encryptLocation, int day) {
		try {
			Path folder = Paths.get(location);
			List<File> audioFiles = new ArrayList<>();
			Files.walk(folder)
					.filter(file -> file.toFile().isFile() && (file.toString().endsWith(".wav"))
							&& System.currentTimeMillis() - file.toFile().lastModified() > TimeUnit.DAYS.toMillis(day))
					.forEach(file -> audioFiles.add(file.toFile()));
			return audioFiles;
		} catch (Exception ex) {
			logger.error("Error while Finding file : " + GetStackTrace.getMessage(ex));
			return null;
		}
	}

//public static void main(String[] args) {
//	System.out.println(System.currentTimeMillis() - new File("D:\\CXC\\audio\\down\\EnglishSelection.wav").lastModified());
//	System.out.println(TimeUnit.DAYS.toMillis(1));
//}
	private File fileEncryption(String filePath, String storePath) {
		try {
			String salt = "ulaj6@CB#tv$50p!50c35onsM!";
			String key = "jcasihkihkhxzkuhousahohkzhxkhoihxlj2yJdI9HbQi8YcCo8TvcvSN88rrceNlCepMcs2deX9+rWjGr0My58DzFZs+lAZWy4AfiknckjjdljljxzlnokjpoakjbxzicxVPt6a7JTK2o0I42RcBgGQO8DGHt76woiwqjoiwytr46EGWIUJODSJAPIW";
			FileInputStream inFile = new FileInputStream(filePath);
			FileOutputStream outFile = new FileOutputStream(storePath);
			SecretKeyFactory factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");
			KeySpec keySpec = new PBEKeySpec(key.toCharArray(), salt.getBytes(), 65536, 256);
			SecretKey secretKey = factory.generateSecret(keySpec);
			SecretKey secret = new SecretKeySpec(secretKey.getEncoded(), "AES");
			byte[] iv = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
			IvParameterSpec ivspec = new IvParameterSpec(iv);
			Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
			cipher.init(Cipher.ENCRYPT_MODE, secret, ivspec);
			byte[] input = new byte[64];
			int bytesRead;
			while ((bytesRead = inFile.read(input)) != -1) {
				byte[] output = cipher.update(input, 0, bytesRead);
				if (output != null)
					outFile.write(output);
			}
			byte[] output = cipher.doFinal();
			if (output != null)
				outFile.write(output);
			inFile.close();
			outFile.flush();
			outFile.close();
			return new File(storePath);
		} catch (Exception e) {
			logger.error("Error while Encrypt file : " + filePath + " : " + GetStackTrace.getMessage(e));
			return null;
		}

	}
}
