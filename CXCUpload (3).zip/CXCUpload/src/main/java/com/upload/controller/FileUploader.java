package com.upload.controller;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import com.upload.service.FileUpload;
import com.upload.util.ApplicationConstants;
import com.upload.util.Configurations;
import com.upload.util.GetStackTrace;

@RestController
public class FileUploader {
	Logger logger = LogManager.getLogger(FileUploader.class);

	@Autowired
	FileUpload fileuploader;

	@PostMapping(value = "/upload", produces = MediaType.APPLICATION_JSON_VALUE)
	public String multiUpload() {
		new Configurations().loadJson(ApplicationConstants.CONFIG_FILE_PATH);
		logger.info("config data : " + Configurations.CONFIG);
		JSONArray filejs = new JSONArray();
		try {
			if (Configurations.CONFIG != null && Configurations.CONFIG.length() > 0) {
				for (int i = 0; i < Configurations.CONFIG.length(); i++) {
					JSONObject fileDetails = new JSONObject();
					if (Configurations.CONFIG.getJSONObject(i).has("customerName")) {
						JSONArray fileupload = fileuploader.fileupload(Configurations.CONFIG.getJSONObject(i), 0);
						if (fileupload != null && fileupload.length() > 0) {
							fileDetails.put("customerName",
									Configurations.CONFIG.getJSONObject(i).getString("customerName"));
							fileDetails.put("uploadData", fileupload);
						} else {
							fileDetails.put("customerName",
									Configurations.CONFIG.getJSONObject(i).getString("customerName"));
							fileDetails.put("uploadData", "No Data");
						}
					} else {
						logger.error("No customer Name in config file");
						fileDetails.put("customerName", "no name");
						fileDetails.put("uploadData", "No data");
					}
					filejs.put(fileDetails);
				}
				logger.info("Uploaded files data : " + filejs.toString());
				return filejs.toString();
			} else {
				logger.error("Exception while reading in Config file ");
				logger.info("Uploaded files data : " + filejs.toString());
				return filejs.toString();
			}
		} catch (Exception e) {
			logger.error("Exception while upload Files : " + GetStackTrace.getMessage(e));
			logger.info("Uploaded files data : " + filejs.toString());
			return filejs.toString();
		}
	}

	@PostMapping(value = "/upload/{dayCount}", produces = MediaType.APPLICATION_JSON_VALUE)
	public String multiUpload(@PathVariable(value = "dayCount") int dayCount) {
		new Configurations().loadJson(ApplicationConstants.CONFIG_FILE_PATH);
		logger.info("config data : " + Configurations.CONFIG);
		JSONArray filejs = new JSONArray();
		try {
			if (Configurations.CONFIG != null && Configurations.CONFIG.length() > 0) {
				for (int i = 0; i < Configurations.CONFIG.length(); i++) {
					JSONObject fileDetails = new JSONObject();
					if (Configurations.CONFIG.getJSONObject(i).has("customerName")) {
						JSONArray fileupload = fileuploader.fileupload(Configurations.CONFIG.getJSONObject(i),
								dayCount);
						if (fileupload != null && fileupload.length() > 0) {
							fileDetails.put("customerName",
									Configurations.CONFIG.getJSONObject(i).getString("customerName"));
							fileDetails.put("uploadData", fileupload);
						} else {
							fileDetails.put("customerName",
									Configurations.CONFIG.getJSONObject(i).getString("customerName"));
							fileDetails.put("uploadData", "No Data");
						}
					} else {
						logger.error("No customer Name in config file");
						fileDetails.put("customerName", "no name");
						fileDetails.put("uploadData", "No data");
					}
					filejs.put(fileDetails);
				}
				logger.info("Uploaded files data : " + filejs.toString());
				return filejs.toString();
			} else {
				logger.info("Uploaded files data : " + filejs.toString());
				logger.error("Exception while reading in Config file ");
				return filejs.toString();
			}
		} catch (Exception e) {
			logger.info("Uploaded files data : " + filejs.toString());
			logger.error("Exception while upload Files : " + GetStackTrace.getMessage(e));
			return filejs.toString();
		}
	}

}
