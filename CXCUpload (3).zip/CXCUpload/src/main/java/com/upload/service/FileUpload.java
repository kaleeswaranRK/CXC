package com.upload.service;

import java.io.File;
import java.util.List;

import org.apache.http.HttpEntity;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.client.methods.RequestBuilder;
import org.apache.http.entity.mime.HttpMultipartMode;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.upload.util.FileOperation;
import com.upload.util.GetStackTrace;

@Service
public class FileUpload {
	@Autowired
	FileOperation fileOperation;
	Logger logger = LogManager.getLogger(FileUpload.class);

	public JSONArray fileupload(JSONObject filedetails, int daysCount) {
		try {
			List<File> findFiles = null;
			findFiles = fileOperation.findFiles(filedetails.getString("localPath"),
					filedetails.getString("encryptPath"), daysCount);
			if (findFiles != null && findFiles.size() > 0) {
				CloseableHttpClient httpclient = HttpClientBuilder.create().build();
				CloseableHttpResponse httpresponse = null;
				MultipartEntityBuilder entitybuilder = MultipartEntityBuilder.create();
				entitybuilder.setMode(HttpMultipartMode.BROWSER_COMPATIBLE);
				List<File> ecryptfiles = fileOperation.dbcheck(findFiles, filedetails.getJSONObject("databaseConnect"),
						filedetails.getString("encryptPath"));
				if (ecryptfiles != null) {
					for (File file : findFiles) {
						entitybuilder.addBinaryBody("files", file);
					}
					HttpEntity mutiPartHttpEntity = entitybuilder.build();
					RequestBuilder reqbuilder = RequestBuilder.post(filedetails.getString("uploadAPI"));
					RequestConfig config = RequestConfig.custom().setConnectTimeout(5 * 3000)
							.setConnectionRequestTimeout(5 * 3000).setSocketTimeout(5 * 3000).build();
					reqbuilder.setConfig(config);
					reqbuilder.setEntity(mutiPartHttpEntity);
					HttpUriRequest multipartRequest = reqbuilder.build();
					httpresponse = httpclient.execute(multipartRequest);
					if (httpresponse.getStatusLine().getStatusCode() == 200
							&& httpresponse.getStatusLine().getStatusCode() < 300) {
						String uploadresponse = EntityUtils.toString(httpresponse.getEntity(), "UTF-8");
						logger.info("Upload API Response : " + uploadresponse);
						if (uploadresponse != null) {
							JSONArray jsonArray = new JSONArray(uploadresponse);
							if (jsonArray != null && jsonArray.length() > 0) {
								return fileOperation.deleteFileMethod(jsonArray, filedetails.getString("encryptPath"),
										filedetails.getString("localPath"));
							} else {
								return null;
							}
						} else {
							return null;
						}
					} else {
						fileOperation.removeAllFiles(filedetails.getString("encryptPath"));
						logger.error("Error while Upload file and status code : "
								+ httpresponse.getStatusLine().getStatusCode());
						return null;
					}
				} else {
					logger.error("Error while connecting database ");
					return null;
				}

			} else {
				logger.error("No files Available in current path : " + filedetails.getString("localPath"));
				return null;
			}

		} catch (

		Exception e) {
			logger.error("Error while upload file : " + GetStackTrace.getMessage(e));
			return null;
		}
	}
}
