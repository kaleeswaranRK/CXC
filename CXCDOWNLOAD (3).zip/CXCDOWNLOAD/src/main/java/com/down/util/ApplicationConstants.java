package com.down.util;

public class ApplicationConstants {

	public static final String CONFIG_FILE_PATH = System.getProperty("catalina.base")
			.concat("\\ApplicationConfiguration\\CXC\\downloadconfig.json");
	public static final String POSTGRES_DRIVER = "org.postgresql.Driver";
	public static final String POSTGRES_PREFIX = "jdbc:postgresql://";
	// public static final String LOG_CONFIG_FILE_PATH =
	// System.getProperty("catalina.base").concat("\\ApplicationConfiguration\\ServerSentinel\\logConfig.xml");
//	public static final String POSTGRES_PREFIX = "jdbc:sqlserver://";
//	public static final String POSTGRES_DRIVER = "com.microsoft.sqlserver.jdbc.SQLServerDriver";

}
