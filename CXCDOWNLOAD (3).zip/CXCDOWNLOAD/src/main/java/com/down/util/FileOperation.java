package com.down.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.net.MalformedURLException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.security.spec.KeySpec;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

@Service
public class FileOperation {
	Logger logger = LogManager.getLogger(FileOperation.class);

	public JSONObject uploadToLocalFileSystem(MultipartFile file, String encryptPath) {
		JSONObject res = new JSONObject();
		if (file == null || file.isEmpty()) {
			logger.error("Exception while upload file : file is empty");
			res.put("fileName", "");
			res.put("filePath", "Nil");
			res.put("uploadStatus", "failiure");
			return res;
		} else {
			String fileName = StringUtils.cleanPath(file.getOriginalFilename());
			Path path = Paths.get(encryptPath);
			try {
				if (!Files.exists(path)) {
					Files.createDirectories(path);
				}
				Path filePath = path.resolve(fileName);
				Files.copy(file.getInputStream(), filePath, StandardCopyOption.REPLACE_EXISTING);
				res.put("fileName", fileName);
				res.put("filePath", filePath.toString());
				res.put("uploadStatus", "success");
				return res;
			} catch (Exception e) {
				logger.error("Exception while upload file : " + GetStackTrace.getMessage(e));
				res.put("fileName", fileName);
				res.put("filePath", "Nil");
				res.put("uploadStatus", "failiure");
				return res;
			}
		}

	}

	private String getFileSizeWithSuffix(long fileSize) {
		double size = fileSize;
		String suffix = "B";
		if (size > 1024) {
			suffix = "KB";
			size /= 1024;
		}
		if (size > 1024) {
			suffix = "MB";
			size /= 1024;
		}
		if (size > 1024) {
			suffix = "GB";
			size /= 1024;
		}
		return String.format("%.2f %s", size, suffix);
	}

	public JSONArray filedownload(String encrypt, String downloadPath) throws MalformedURLException {
		JSONArray JSONObjectList = new JSONArray();
		Path dirPath = Paths.get(encrypt);
		List<File> findFiles = findFiles(dirPath.toString());
		for (int i = 0; i < findFiles.size(); i++) {
			JSONObject res = new JSONObject();
			if (fileDecryption(findFiles.get(i).toString(),
					Paths.get(downloadPath).resolve(findFiles.get(i).getName()).toString())) {
				res.put("fileName", findFiles.get(i).getName().replace(".wav", ""));
				res.put("filePath", Paths.get(downloadPath).resolve(findFiles.get(i).getName()).toString());
				res.put("fileSize", getFileSizeWithSuffix(findFiles.get(i).length()));
				res.put("downloadStatus", "success");
				if (findFiles.get(i).delete()) {
					res.put("removeStatus", "success");
				} else {
					res.put("removeStatus", "failiure");
				}
			} else {
				res.put("fileName", findFiles.get(i).getName().replace(".wav", ""));
				res.put("filePath", "Nil");
				res.put("fileSize", getFileSizeWithSuffix(findFiles.get(i).length()));
				res.put("downloadStatus", "failiure");
				res.put("removeStatus", "failiure");
			}
			JSONObjectList.put(res);
		}
		return JSONObjectList;
	}

	private List<File> findFiles(String location) {
		try {
			Path folder = Paths.get(location);
			List<File> audioFiles = new ArrayList<>();
			Files.walk(folder).filter(file -> file.toFile().isFile()).forEach(file -> audioFiles.add(file.toFile()));
			return audioFiles;
		} catch (Exception ex) {
			logger.error("Exception while find file " + GetStackTrace.getMessage(ex));
			return null;
		}
	}

	public JSONArray fileremove(String location, int dayCount) throws IOException {
		JSONArray fileList = new JSONArray();
		Path folder = Paths.get(location);
		List<File> audioFiles = new ArrayList<>();
		Files.walk(folder)
				.filter(file -> file.toFile().isFile()
						&& System.currentTimeMillis() - file.toFile().lastModified() > TimeUnit.DAYS.toMillis(dayCount))
				.forEach(file -> audioFiles.add(file.toFile()));
		for (File file : audioFiles) {
			JSONObject fileRemoved = new JSONObject();
			fileRemoved.put("fileName", file.getName());
			fileRemoved.put("fileSize", getFileSizeWithSuffix(file.length()));
			fileRemoved.put("filePath", file.toString());
			if (file.delete()) {
				fileRemoved.put("removeStatus", "success");
			} else {
				fileRemoved.put("removeStatus", "failiure");
			}
			fileList.put(fileRemoved);

		}
		return fileList;
	}

//	public static void main(String[] args) throws IOException {
//		SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");
//		String flatName = "flatfile".concat(new SimpleDateFormat("dd-MM-yyyy").format(new Date())).concat(".json");
//		System.out.println(flatName);
//	}

	public void flatFileCreation(String path, JSONArray fileArray, String flatName) {
		Path folder = Paths.get(path);
		List<File> flatFiles = new ArrayList<>();
		String fileContents = "";
		if (new File(path).exists()) {
			String fileName = folder
					.resolve(flatName.concat(new SimpleDateFormat("dd-MM-yyyy").format(new Date())).concat(".json"))
					.toString();
			FileWriter fileWriter = null;
			try {
				Files.walk(folder)
						.filter(file -> file.toFile().isFile() && file.toFile().toString().equalsIgnoreCase(fileName))
						.forEach(file -> flatFiles.add(file.toFile()));
				if (flatFiles.size() > 0) {
					StringBuilder configStringBuild = new StringBuilder();
					BufferedReader configBufferReader = new BufferedReader(new FileReader(flatFiles.get(0)));
					String line;
					while ((line = configBufferReader.readLine()) != null) {
						configStringBuild.append(line);
						configStringBuild.append(System.lineSeparator());
					}
					fileContents = configStringBuild.toString().trim();
				}
				for (int i = 0; i < fileArray.length(); i++) {
					JSONObject jsonObject = new JSONObject();
					jsonObject.put("fileName", fileArray.getJSONObject(i).getString("fileName"));
					jsonObject.put("downloadStatus", fileArray.getJSONObject(i).getString("downloadStatus"));
					fileContents = jsonObject.toString() + "\n" + fileContents;
				}
				fileWriter = new FileWriter(fileName);
				fileWriter.write(fileContents);
			} catch (Exception e) {
				logger.error("Exception while creating flatfile : " + e);
			} finally {
				try {
					fileWriter.close();
				} catch (Exception e) {
					logger.error("Exception while creating flatfile : " + e);
				}
			}
		} else

		{
			logger.error("Exception while creating flatfile file : " + path + "path not exist");
		}
	}

	public void flatFileCreation(String path, JSONObject filejson, String flatName) {
		Path folder = Paths.get(path);
		List<File> flatFiles = new ArrayList<>();
		String fileContents = "";
		if (new File(path).exists()) {
			String fileName = folder
					.resolve(flatName.concat(new SimpleDateFormat("dd-MM-yyyy").format(new Date())).concat(".json"))
					.toString();
			FileWriter fileWriter = null;
			try {
				Files.walk(folder)
						.filter(file -> file.toFile().isFile() && file.toFile().toString().equalsIgnoreCase(fileName))
						.forEach(file -> flatFiles.add(file.toFile()));
				if (flatFiles.size() > 0) {
					StringBuilder configStringBuild = new StringBuilder();
					BufferedReader configBufferReader = new BufferedReader(new FileReader(flatFiles.get(0)));
					String line;
					while ((line = configBufferReader.readLine()) != null) {
						configStringBuild.append(line);
						configStringBuild.append(System.lineSeparator());
					}
					fileContents = configStringBuild.toString().trim();
				}
				JSONObject jsonObject = new JSONObject();
				jsonObject.put("fileName", filejson.getString("fileName"));
				jsonObject.put("downloadStatus", filejson.getString("downloadStatus"));
				fileContents = jsonObject.toString() + "\n" + fileContents;
				fileWriter = new FileWriter(fileName);
				fileWriter.write(fileContents);
				logger.error("Flat file created : " + fileName);
			} catch (Exception e) {
				logger.error("Exception while creating flatfile : " + e);
			} finally {
				try {
					fileWriter.close();
				} catch (Exception e) {
					logger.error("Exception while creating flatfile : " + e);
				}
			}
		} else

		{
			logger.error("Exception while creating flatfile file : " + path + "path not exist");
		}
	}

	private boolean fileDecryption(String encryptfile, String decryptfile) {
		try {
			String salt = "ulaj6@CB#tv$50p!50c35onsM!";
			String key = "jcasihkihkhxzkuhousahohkzhxkhoihxlj2yJdI9HbQi8YcCo8TvcvSN88rrceNlCepMcs2deX9+rWjGr0My58DzFZs+lAZWy4AfiknckjjdljljxzlnokjpoakjbxzicxVPt6a7JTK2o0I42RcBgGQO8DGHt76woiwqjoiwytr46EGWIUJODSJAPIW";
			byte[] iv = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
			IvParameterSpec ivspec = new IvParameterSpec(iv);
			SecretKeyFactory factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");
			KeySpec keySpec = new PBEKeySpec(key.toCharArray(), salt.getBytes(), 65536, 256);
			SecretKey tmp = factory.generateSecret(keySpec);
			SecretKey secret = new SecretKeySpec(tmp.getEncoded(), "AES");
			Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
			cipher.init(Cipher.DECRYPT_MODE, secret, ivspec);
			FileInputStream fis = new FileInputStream(encryptfile);
			FileOutputStream fos = new FileOutputStream(decryptfile);
			byte[] in = new byte[64];
			int read;
			while ((read = fis.read(in)) != -1) {
				byte[] output = cipher.update(in, 0, read);
				if (output != null)
					fos.write(output);
			}

			fis.close();
			fos.flush();
			fos.close();
			return true;
		} catch (Exception e) {
			logger.error("Exception while Encrypt file " + GetStackTrace.getMessage(e));
			return false;
		}
	}
}
