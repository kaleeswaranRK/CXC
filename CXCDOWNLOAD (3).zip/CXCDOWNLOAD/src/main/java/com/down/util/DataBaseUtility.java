package com.down.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONObject;
import org.postgresql.util.PSQLException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class DataBaseUtility {
	Logger logger = LogManager.getLogger(DataBaseUtility.class);

	@Autowired
	Cryptography crypto;

	public Connection getDatabaseConnection(JSONObject databaseconnect) {
		try {
			String connectionPrefix = null;
			String connectionString = null;
			connectionPrefix = ApplicationConstants.POSTGRES_PREFIX;
			connectionString = connectionPrefix.concat(databaseconnect.getString("hostname")).concat("/")
					.concat(databaseconnect.getString("schema"));
			Class.forName(ApplicationConstants.POSTGRES_DRIVER);
			return DriverManager.getConnection(connectionString,
					databaseconnect.getJSONObject("credentials").getString("userName"),
					crypto.getPlainText(databaseconnect.getJSONObject("credentials").getString("password")));
		} catch (Exception ex) {
			logger.error("Exception while configuring DatabaseConnection : " + GetStackTrace.getMessage(ex));
			return null;
		}
	}

	public boolean dbData(JSONObject databaseData, Connection databaseConnection, String query) {
		PreparedStatement Statement = null;
		try {
			Statement = databaseConnection.prepareStatement(query);
			Statement.setString(1, databaseData.getString("fileName"));
			Statement.setString(2, databaseData.getString("downloadStatus"));
			int executeUpdate = Statement.executeUpdate();
			if (executeUpdate > 0) {
				return true;
			} else {
				return false;
			}
		} catch (PSQLException e) {
			logger.error("Exception while configuring DatabaseConnection : " + GetStackTrace.getMessage(e));
			return false;
		} catch (Exception e) {
			logger.error("Exception while configuring DatabaseConnection : " + GetStackTrace.getMessage(e));
			return false;
		} finally {
			try {
				Statement.close();
			} catch (Exception e) {
				logger.error("Exception while configuring DatabaseConnection : " + GetStackTrace.getMessage(e));
			}
		}
	}
}