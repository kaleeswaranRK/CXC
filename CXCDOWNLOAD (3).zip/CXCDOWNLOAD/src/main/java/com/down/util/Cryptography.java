package com.down.util;

//AES256 Encryption
import java.security.spec.KeySpec;
import java.util.Base64;
import java.util.UUID;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Service;
@Service
public class Cryptography {
	Logger logger = LogManager.getLogger(Cryptography.class);

	protected String secretKey = "upajnakj2skkj7sk0jznkjnzkjnnR3EZ2pPqjVPJdI9HbQi8YcCo8TvcvSN88rrceNlC2epMcs2deX9+rWjGr0My58DzFZs+lAZWy4Afi/VPt6a7JTK2o0I42RcBgGQO8DG@hdhojnso+i3lkjij(d+xx0kzcDxTzRedx4VpIe8tEy1sKqFfDfHSoewk=xmpj)5gwjsj";
	protected String salt = "Dlanwb6@CB#tv$50p!50c35&pwmk9";

	private String encrypt(String strToEncrypt, String secret) {
		try {
			byte[] iv = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
			IvParameterSpec ivspec = new IvParameterSpec(iv);
			SecretKeyFactory factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");
			KeySpec spec = new PBEKeySpec(secretKey.toCharArray(), salt.getBytes(), 65536, 256);
			SecretKey tmp = factory.generateSecret(spec);
			SecretKeySpec secretKey = new SecretKeySpec(tmp.getEncoded(), "AES");
			Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
			cipher.init(Cipher.ENCRYPT_MODE, secretKey, ivspec);
			return Base64.getEncoder().encodeToString(cipher.doFinal(strToEncrypt.getBytes("UTF-8")));
		} catch (Exception ex) {
			logger.error("Exception while Encrypt : " + GetStackTrace.getMessage(ex));
		}
		return null;
	}

	private String decrypt(String strToDecrypt, String secret) {
		try {
			byte[] iv = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
			IvParameterSpec ivspec = new IvParameterSpec(iv);
			SecretKeyFactory factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");
			KeySpec spec = new PBEKeySpec(secretKey.toCharArray(), salt.getBytes(), 65536, 256);
			SecretKey tmp = factory.generateSecret(spec);
			SecretKeySpec secretKey = new SecretKeySpec(tmp.getEncoded(), "AES");
			Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
			cipher.init(Cipher.DECRYPT_MODE, secretKey, ivspec);
			String temp = new String(cipher.doFinal(Base64.getDecoder().decode(strToDecrypt)));
			String returnValue = temp.substring(16, temp.length() - 1);
			return returnValue.substring(0, returnValue.length() - 15);
		} catch (Exception ex) {
			logger.error("Exception while Decrypt : " + GetStackTrace.getMessage(ex));
		}
		return null;
	}

	public String getPlainText(String cipher) {
		Cryptography security = new Cryptography();
		if (cipher != null && cipher.trim().length() > 0) {
			return security.decrypt(cipher, secretKey);
		} else {
			return null;
		}
	}

	public String getCipher(String plainText) {
		String uuid = UUID.randomUUID().toString().replaceAll("-", "");
		Cryptography security = new Cryptography();
		return security.encrypt(uuid.substring(0, 16).concat(plainText).concat(uuid.substring(16, 32)), secretKey);
	}
//	public static void main(String[] args) {
//		String cipher = new Cryptography().getCipher("testuser");
//		System.out.println(cipher);
//	}
}