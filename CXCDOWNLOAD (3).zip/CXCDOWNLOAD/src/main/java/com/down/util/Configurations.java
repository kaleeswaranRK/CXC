package com.down.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONObject;

public class Configurations {

	Logger logger = LogManager.getLogger(Configurations.class);

	public static JSONObject CONFIG;

	public boolean loadJson(String confgiFilePath) {
		File config = new File(confgiFilePath);
		if (config.exists() && config.isFile()) {
			StringBuilder configStringBuild = new StringBuilder();
			try (BufferedReader configBufferReader = new BufferedReader(new FileReader(confgiFilePath))) {
				String line;
				while ((line = configBufferReader.readLine()) != null) {
					configStringBuild.append(line);
					configStringBuild.append(System.lineSeparator());
				}
				String fileContents = configStringBuild.toString();
				if (fileContents.length() > 0) {
					CONFIG = new JSONObject(fileContents);
					return true;
				} else {
					logger.error("Invalid File");
					return false;
				}
			} catch (Exception ex) {
				logger.error("Error while reading file: " + GetStackTrace.getMessage(ex));
				return false;
			}
		} else {
			logger.error("Unable to find the file in " + confgiFilePath);
			return false;
		}
	}
}