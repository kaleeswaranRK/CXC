package com.down.controller;

import java.io.IOException;
import java.sql.Connection;
import java.util.Arrays;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.down.util.ApplicationConstants;
import com.down.util.Configurations;
import com.down.util.DataBaseUtility;
import com.down.util.FileOperation;
import com.down.util.GetStackTrace;

@RestController
public class FileDownloader {
	Logger logger = LogManager.getLogger(FileDownloader.class);

	@Autowired
	FileOperation fileoperation;

	@Autowired
	DataBaseUtility database;

	@GetMapping(value = "/download", produces = MediaType.APPLICATION_JSON_VALUE)
	public String downloadFileFromLocal() throws IOException {
		new Configurations().loadJson(ApplicationConstants.CONFIG_FILE_PATH);
		JSONArray filedownload = new JSONArray();
		try {
			if (Configurations.CONFIG != null && Configurations.CONFIG.length() > 0
					&& Configurations.CONFIG.has("encryptPath") && Configurations.CONFIG.has("decryptPath")) {
				filedownload = fileoperation.filedownload(Configurations.CONFIG.getString("encryptPath"),
						Configurations.CONFIG.getString("decryptPath"));
				if (filedownload != null && filedownload.length() > 0) {
					if (Configurations.CONFIG.has("databaseAccess")
							&& "yes".equalsIgnoreCase(Configurations.CONFIG.getString("databaseAccess"))) {
						Connection databaseConnection = database
								.getDatabaseConnection(Configurations.CONFIG.getJSONObject("databaseConnect"));
						if (databaseConnection != null) {
							for (int i = 0; i < filedownload.length(); i++) {
								if (database.dbData(filedownload.getJSONObject(i), databaseConnection,
										Configurations.CONFIG.getJSONObject("databaseConnect").getString("query"))) {
								} else {
									if (Configurations.CONFIG.has("flatfilePath")
											&& Configurations.CONFIG.has("flatfileName")) {
										fileoperation.flatFileCreation(Configurations.CONFIG.getString("flatfilePath"),
												filedownload.getJSONObject(i),
												Configurations.CONFIG.getString("flatfileName"));
									}
								}
							}
							try {
								databaseConnection.close();
							} catch (Exception e) {
								logger.error("Exception while connect Database" + GetStackTrace.getMessage(e));
							}
						} else {
							if (Configurations.CONFIG.has("flatfilePath")
									&& Configurations.CONFIG.has("flatfileName")) {
								fileoperation.flatFileCreation(Configurations.CONFIG.getString("flatfilePath"),
										filedownload, Configurations.CONFIG.getString("flatfileName"));
							}
						}
					}
				}
			}
			logger.info("Download Status : " + filedownload.toString());
			return filedownload.toString();
		} catch (Exception e) {
			logger.error("Execption while upload files : " + GetStackTrace.getMessage(e));
			logger.info("Download Status : " + filedownload.toString());
			return filedownload.toString();
		}
	}

	@PostMapping(value = "/delete/{daysCount}", produces = MediaType.APPLICATION_JSON_VALUE)
	public String deleteFiles(@PathVariable(value = "daysCount") int daysCount) throws IOException {
		new Configurations().loadJson(ApplicationConstants.CONFIG_FILE_PATH);
		JSONObject delete = new JSONObject();
		try {
			if (Configurations.CONFIG != null && Configurations.CONFIG.length() > 0
					&& Configurations.CONFIG.has("decryptPath")) {
				JSONArray fileremove = fileoperation.fileremove(Configurations.CONFIG.getString("decryptPath"),
						daysCount);
				delete.put("removedData", fileremove);
			}
			logger.info("Delete Status : " + delete.toString());
			return delete.toString();
		} catch (Exception e) {
			logger.error("Execption while delete files : " + GetStackTrace.getMessage(e));
			logger.info("Delete Status : " + delete.toString());
			return delete.toString();
		}
	}

	@PostMapping(value = "/receive", produces = MediaType.APPLICATION_JSON_VALUE)
	public String multiUpload(@RequestParam("files") MultipartFile[] files) {
		new Configurations().loadJson(ApplicationConstants.CONFIG_FILE_PATH);
		JSONArray fileResponse = new JSONArray();
		try {
			if (Configurations.CONFIG != null && Configurations.CONFIG.length() > 0
					&& Configurations.CONFIG.has("encryptPath")) {
				String path = Configurations.CONFIG.getString("encryptPath");
				Arrays.asList(files).stream()
						.forEach(file -> fileResponse.put(fileoperation.uploadToLocalFileSystem(file, path)));
			}
			logger.info("upload status : " + fileResponse.toString());
			return fileResponse.toString();
		} catch (Exception e) {
			logger.error("Execption while upload files : " + GetStackTrace.getMessage(e));
			logger.info("upload status : " + fileResponse.toString());
			return fileResponse.toString();
		}
	}

}
